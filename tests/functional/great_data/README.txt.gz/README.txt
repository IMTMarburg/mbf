There are three data files in this bundle, described below.

### hg18.loci ###
This file contains information for all genes in the hg18 gene set that are annotated with the GO Cellular Component term
GO:0015629 ("actin cytoskeleton").
Its format is a five-column tab-delimited file, with the following columns:

1. UCSC Cluster ID (basically used as a unique identifier for the gene)
2. Chromosome of the transcription start site
3. Base pair of the transcription start site
4. Strand of the gene
5. Name of the gene (used for visualization in the browser)

### hg18.regdoms ###
This file is a standard BED file (http://genome.ucsc.edu/FAQ/FAQformat#format1) of the regulatory domains used for
each gene in the loci file above.
The 4th field is the UCSC Cluster ID of the associated gene, and thus maps to the first field of the
hg18.loci file.

### hg18.antigap.bed ###
This file is a standard BED file of all regions in the genome that should be used to calculate the total number of
base pairs in the genome annotated with the term.  I.e. the sum of all ranges in this file
is the denominator in the binomial weight calculation.  For each annotation term, the numerator in the weight calculation is
(UNION of all regulatory domains of genes annotated with the term) INTERSECT (UNION of all antigap ranges).



Using these files, the denominator of the equation to calculate the weight of the genome associated with the
GO term GO:0015629 is 2858034764.

The numerator of the equation is the union of all regulatory domains given, intersected with the non-gap
basepair file, which ends up being 60732793 bp.
Note that this number is less than just summing up the lengths of each gene regulatory domain separately
(=62102612 bp) because of computational regulatory domain extension into gaps as well as overlapping regulatory
domains of genes annotated with the term (e.g. the MYH gene cluster on chr17).

